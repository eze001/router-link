import Vue from 'vue';
import VueRouter from 'vue-router';

import Inicio from '../components/Inicio';  // asumiendo que hicimos este componente
import Ingreso from '../components/Ingreso';
import Restoran from '../components/Restoran';
import Categoria from '../components/Categoria';
import NoEncontrada from '../components/NoEncontrada';
import AcercaDe from '../components/AcercaDe';
import Revisiones from '../components/Revisiones';
import Imagenes from '../components/Imagenes';

Vue.use(VueRouter);    // instalamos explícitamente el router

export default new VueRouter({
    routes: [
        {
            path: '/', 
            component: Inicio
        },
        {
            path: '/login',
            component: Ingreso
        },
        {
            path: '/restoran/:nombrerestoran',
            component: Restoran,
            children: [
                {
                    path:'',
                    component:AcercaDe
                },
                {
                    path:'reviews',
                    component: Revisiones
                },
                {
                    path:'images',
                    component: Imagenes
                }
            ]
        },
        {
            path: '/category/:nombrecategoria',
            component: Categoria
        },
        {
            path: '*',
            component: NoEncontrada,
        },
    ]
})
