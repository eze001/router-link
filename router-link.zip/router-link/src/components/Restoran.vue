<template>
    <div id="Restoran">
        <router-link id="acercade" v-bind:to="{path:'/restoran/'+$route.params.nombrerestoran}">AcercaDe</router-link>
        <router-link id="revisiones" v-bind:to="{path:'/restoran/'+$route.params.nombrerestoran+'/reviews'}">Revisiones</router-link>
        <router-link id="imagenes" v-bind:to="{path:'/restoran/'+$route.params.nombrerestoran+'/images'}">Imagenes</router-link>
        <!--reviews
        'images'-->
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'Restoran'
    }
</script>

<style scoped>
    #Restoran{
        margin-top:10px;
    }
    #acercade,#revisiones,#imagenes{
        margin:10px;
    }
</style> 