<template>
    <div id="Imagenes">
        <p id="titulo">{{ $route.params.nombrerestoran }}</p>
        <img class="yoshi" alt="dibujo" src="./yoshi1.jpg">
        <img class="yoshi" alt="dibujo" src="./yoshi2.jpg">
        <img class="yoshi" alt="dibujo" src="./yoshi3.jpg">
    </div>
</template>

<script>
    export default{
        name:'Imagenes'
    }
</script>

<style scoped>
    #titulo{
        margin-left:100px;
        margin-top:20px;
        font-size:40px;
    }
    .yoshi{
        margin:10px;
        display:block;
        width:400px;
        height:300px;
    }
</style>