<template>
  <div id="app">
    <router-link id="inicio" v-bind:to="{path:'/'}">Inicio</router-link>
    <router-view />
  </div>
</template>

<script>

export default {
  name: 'App',
}
</script>

<style scoped>
  #inicio{
    margin:10px;
  }
  #app{
    margin-bottom:10px;
  }
</style>